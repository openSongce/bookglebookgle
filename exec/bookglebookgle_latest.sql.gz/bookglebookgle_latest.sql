-- MySQL dump 10.13  Distrib 8.4.5, for Linux (x86_64)
--
-- Host: localhost    Database: bookglebookgle
-- ------------------------------------------------------
-- Server version	8.4.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `bookglebookgle`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `bookglebookgle` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `bookglebookgle`;

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmark` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `page` int NOT NULL,
  `group_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKi343r6lo84wpfnydtajausg8v` (`group_id`),
  KEY `FKo4vbqvq5trl11d85bqu5kl870` (`user_id`),
  CONSTRAINT `FKi343r6lo84wpfnydtajausg8v` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`),
  CONSTRAINT `FKo4vbqvq5trl11d85bqu5kl870` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmark`
--

LOCK TABLES `bookmark` WRITE;
/*!40000 ALTER TABLE `bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_message`
--

DROP TABLE IF EXISTS `chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_message` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  `sender_id` bigint DEFAULT NULL,
  `type` enum('NORMAL','SYSTEM') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5f82aoyy0jiwpj08qapfrxbh6` (`sender_id`),
  KEY `ix_msg_room_type_id` (`room_id`,`type`,`id`),
  KEY `ix_msg_room_id` (`room_id`),
  KEY `idx_chat_msg_room_id_id` (`room_id`,`id`),
  KEY `idx_chat_msg_room_id_created_at` (`room_id`,`created_at`),
  CONSTRAINT `FK5f82aoyy0jiwpj08qapfrxbh6` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fk_chat_message_room` FOREIGN KEY (`room_id`) REFERENCES `chat_room` (`group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=240 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_message`
--

LOCK TABLES `chat_message` WRITE;
/*!40000 ALTER TABLE `chat_message` DISABLE KEYS */;
INSERT INTO `chat_message` VALUES (11,'안녕하세요!','2025-08-17 10:38:04.953000',3,1,'NORMAL'),(12,'안녕하세요','2025-08-17 10:38:19.604000',3,2,'NORMAL'),(13,'같이 활동 잘 해봐요!','2025-08-17 10:38:32.152000',3,1,'NORMAL'),(14,'잘 부탁드립니다!','2025-08-17 10:38:58.711000',3,1,'NORMAL'),(20,'안녕하세요','2025-08-17 11:31:37.185000',6,2,'NORMAL'),(21,'안녕하세요 반가워요!','2025-08-17 11:31:40.169000',6,1,'NORMAL'),(22,'잘 부탁드립니다','2025-08-17 11:31:45.139000',6,2,'NORMAL'),(211,'안녕하세요','2025-08-17 23:14:53.256000',4,4,'NORMAL'),(212,'안녕하세요~','2025-08-17 23:15:22.312000',7,4,'NORMAL'),(213,'오늘 고생 많으셨습니다','2025-08-17 23:16:10.352000',9,4,'NORMAL'),(214,'알고리즘 너무 어렵네요..','2025-08-17 23:17:15.048000',10,4,'NORMAL'),(215,'열심히 해야겠어요..','2025-08-17 23:17:31.040000',10,4,'NORMAL'),(230,'안녕하세요!','2025-08-18 07:40:43.716000',56,1,'NORMAL'),(231,'반가워요!!','2025-08-18 07:40:54.363000',56,4,'NORMAL'),(232,'시간 언제쯤 괜찮으실까요??','2025-08-18 07:41:04.417000',56,1,'NORMAL'),(233,'토요일 어떠신가요??','2025-08-18 07:41:17.906000',56,4,'NORMAL'),(234,'안녕하세요','2025-08-18 07:46:13.000000',57,1,'NORMAL'),(235,'안녕하세요!','2025-08-18 07:46:19.533000',57,4,'NORMAL'),(236,'일요일 스터디 시간 괜찮으실까요??','2025-08-18 07:46:27.514000',57,1,'NORMAL'),(237,'네 좋습니다','2025-08-18 07:46:31.604000',57,4,'NORMAL'),(238,'안녕하세요','2025-08-18 08:03:40.691000',56,1,'NORMAL'),(239,'반갑습니다','2025-08-18 08:03:45.383000',56,4,'NORMAL');
/*!40000 ALTER TABLE `chat_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room`
--

DROP TABLE IF EXISTS `chat_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room` (
  `group_id` bigint NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `group_title` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `last_message` varchar(255) DEFAULT NULL,
  `last_message_time` datetime(6) DEFAULT NULL,
  `member_count` int NOT NULL,
  `last_message_at` datetime(6) DEFAULT NULL,
  `last_message_id` bigint DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  KEY `ix_room_last_msg_at` (`last_message_at`),
  CONSTRAINT `FK8jvb2qb9biq0et50h48s5vg6c` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room`
--

LOCK TABLES `chat_room` WRITE;
/*!40000 ALTER TABLE `chat_room` DISABLE KEYS */;
INSERT INTO `chat_room` VALUES (3,'READING','밤샘 독서 클럽',NULL,NULL,NULL,2,NULL,NULL),(4,'READING','한 달 한 권 챌린지',NULL,NULL,NULL,2,NULL,NULL),(5,'STUDY','하루 1시간 집중 스터디',NULL,NULL,NULL,1,NULL,NULL),(6,'REVIEW','자기소개서 첨삭방',NULL,NULL,NULL,2,NULL,NULL),(7,'READING','심야 북토크',NULL,NULL,NULL,2,NULL,NULL),(8,'REVIEW','에세이 피드백 클럽',NULL,NULL,NULL,1,NULL,NULL),(9,'STUDY','CS 기본기 다지기',NULL,NULL,NULL,2,NULL,NULL),(10,'STUDY','알고리즘 문제 풀이방',NULL,NULL,NULL,2,NULL,NULL),(11,'REVIEW','연구계획서 점검 모임',NULL,NULL,NULL,1,NULL,NULL),(34,'READING','고전 다시 읽기',NULL,NULL,NULL,1,NULL,NULL),(35,'READING','에세이 나눔회',NULL,NULL,NULL,1,NULL,NULL),(36,'READING','책 대신 대화',NULL,NULL,NULL,1,NULL,NULL),(37,'READING','장르 탐험대',NULL,NULL,NULL,1,NULL,NULL),(38,'READING','마음챙김 독서',NULL,NULL,NULL,2,NULL,NULL),(39,'STUDY','자격증 도전 모임',NULL,NULL,NULL,2,NULL,NULL),(40,'STUDY','언어 교환 스터디',NULL,NULL,NULL,1,NULL,NULL),(41,'REVIEW','블로그 글쓰기 첨삭방',NULL,NULL,NULL,1,NULL,NULL),(42,'READING','깃 아마겟돈 피하기',NULL,NULL,NULL,1,NULL,NULL),(43,'REVIEW','이력서 완성 모임',NULL,NULL,NULL,1,NULL,NULL),(44,'STUDY','AI/데이터 스터디',NULL,NULL,NULL,1,NULL,NULL),(45,'STUDY','취업준비 스터디',NULL,NULL,NULL,1,NULL,NULL),(46,'REVIEW','책 리뷰 첨삭 모임',NULL,NULL,NULL,1,NULL,NULL),(47,'REVIEW','논문 초록 첨삭 모임',NULL,NULL,NULL,1,NULL,NULL),(56,'READING','라푼젤 읽기 모임',NULL,NULL,NULL,2,NULL,NULL),(57,'STUDY','SSAFY 퀴즈',NULL,NULL,NULL,2,NULL,NULL),(60,'READING','독서 모임',NULL,NULL,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `chat_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_member`
--

DROP TABLE IF EXISTS `chat_room_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `joined_at` datetime(6) DEFAULT NULL,
  `last_read_message_id` bigint DEFAULT NULL,
  `group_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK41myg4kii6tn1ucem8wk7thau` (`group_id`),
  KEY `ix_member_user_room` (`user_id`,`group_id`),
  CONSTRAINT `FK41myg4kii6tn1ucem8wk7thau` FOREIGN KEY (`group_id`) REFERENCES `chat_room` (`group_id`),
  CONSTRAINT `FKcid1ck7111rvw7w8x2hupdkna` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_member`
--

LOCK TABLES `chat_room_member` WRITE;
/*!40000 ALTER TABLE `chat_room_member` DISABLE KEYS */;
INSERT INTO `chat_room_member` VALUES (3,NULL,14,3,1),(4,NULL,NULL,4,1),(5,NULL,NULL,5,1),(6,NULL,22,6,1),(7,NULL,NULL,7,1),(8,NULL,NULL,8,1),(9,NULL,NULL,9,1),(10,NULL,NULL,10,1),(11,NULL,NULL,11,1),(58,NULL,NULL,34,2),(59,NULL,NULL,35,2),(60,NULL,NULL,36,2),(61,NULL,NULL,37,2),(62,NULL,NULL,38,2),(63,NULL,NULL,39,2),(64,NULL,NULL,40,2),(65,NULL,NULL,41,2),(66,NULL,NULL,42,3),(67,NULL,NULL,43,2),(68,NULL,NULL,44,2),(69,NULL,NULL,45,2),(70,NULL,NULL,46,2),(71,NULL,NULL,47,2),(73,NULL,NULL,38,4),(74,NULL,NULL,39,4),(75,NULL,14,3,4),(76,NULL,211,4,4),(77,NULL,22,6,4),(78,NULL,212,7,4),(79,NULL,213,9,4),(80,NULL,215,10,4),(94,NULL,239,56,1),(95,NULL,239,56,4),(96,NULL,237,57,1),(97,NULL,237,57,4),(100,NULL,NULL,60,1);
/*!40000 ALTER TABLE `chat_room_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `endx` double NOT NULL,
  `endy` double NOT NULL,
  `group_id` bigint DEFAULT NULL,
  `page` int NOT NULL,
  `snippet` varchar(255) DEFAULT NULL,
  `startx` double NOT NULL,
  `starty` double NOT NULL,
  `text` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `pdf_file_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5yyba4nmkbtdtngh5oaf3h6m1` (`pdf_file_id`),
  KEY `FK51gcsymom8d3yu0pnrhs7ob2r` (`group_id`),
  CONSTRAINT `FK51gcsymom8d3yu0pnrhs7ob2r` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`),
  CONSTRAINT `FK5yyba4nmkbtdtngh5oaf3h6m1` FOREIGN KEY (`pdf_file_id`) REFERENCES `pdf_file` (`pdf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (24,'2025-08-18 08:34:01.380561',310.51593017578125,693.190007686615,56,1,'부부가  ',276.8900146484375,693.190007686615,'1',1,NULL),(25,'2025-08-18 08:34:15.624717',121.36592102050781,423.7599844932556,56,1,'바람은  ',87.86399841308594,423.7599844932556,'여기',4,NULL),(26,'2025-08-18 08:34:22.399895',210.4359130859375,594.5499930381775,56,1,'둘러싸여  ',166.94000244140625,594.5499930381775,'ㅋㅋㅋ',4,NULL),(27,'2025-08-18 08:34:24.800505',372.6959228515625,477.1600089073181,56,1,'공간을  ',339.07000732421875,477.1600089073181,'ㅋ',1,NULL),(28,'2025-08-18 10:13:32.441407',238.63592529296875,666.5499930381775,56,3,'머리카락을  ',185.2100067138672,666.5499930381775,'여기',4,NULL),(29,'2025-08-18 10:13:51.708619',121.48595428466797,666.5499930381775,56,3,'“라푼첼아,  ',72.02400207519531,666.5499930381775,'댓글',1,NULL),(30,'2025-08-18 10:13:55.145224',324.3359069824219,613.0299735069275,56,3,'나도  ',300.8900146484375,613.0299735069275,'중요',4,NULL);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','<< Flyway Baseline >>','BASELINE','<< Flyway Baseline >>',NULL,'root','2025-08-10 06:14:02',0,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group` (
  `group_id` bigint NOT NULL AUTO_INCREMENT,
  `category` enum('READING','REVIEW','STUDY') DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `group_max_num` int NOT NULL,
  `is_deleted` bit(1) NOT NULL,
  `min_required_rating` int NOT NULL,
  `progress_percent` float NOT NULL,
  `reading_mode` enum('FOLLOW','FREE','GATE') DEFAULT NULL,
  `room_title` varchar(255) DEFAULT NULL,
  `schedule` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `pdf_id` bigint NOT NULL,
  `total_pages` int NOT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `UK36d62dkprt3qg7gmq6uupl297` (`pdf_id`),
  KEY `FKcslgvb10opts0olfuaemf06i7` (`user_id`),
  CONSTRAINT `FKcslgvb10opts0olfuaemf06i7` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKi70ostatyg3owki6istxm390v` FOREIGN KEY (`pdf_id`) REFERENCES `pdf_file` (`pdf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
INSERT INTO `group` VALUES (3,'READING','2025-08-17 09:14:42.644661','하루 30분이라도 함께 읽고 생각을 나누는 야간 독서 모임.',6,_binary '\0',0,0,'FOLLOW','밤샘 독서 클럽','0 0 21 * * FRI','2025-08-17 09:14:42.644666',1,3,2),(4,'READING','2025-08-17 09:15:07.065459','한 달에 한 권, 함께 완독을 목표로 하는 모임.',5,_binary '\0',1,0,'FOLLOW','한 달 한 권 챌린지','0 0 11 * * THU','2025-08-17 09:15:07.065463',1,4,2),(5,'STUDY','2025-08-17 09:16:17.971334','온라인으로 모여 각자 공부하고 인증하는 모임.',5,_binary '\0',2,0,'FOLLOW','하루 1시간 집중 스터디','0 30 15 * * WED','2025-08-17 09:16:17.971339',1,5,3),(6,'REVIEW','2025-08-17 09:16:50.745340','서로의 자소서를 읽고 피드백을 주고받는 모임.',3,_binary '\0',3,0,'FOLLOW','자기소개서 첨삭방','0 30 16 * * SAT','2025-08-17 09:16:50.745345',1,6,2),(7,'READING','2025-08-17 09:19:03.647964','자기 전 10페이지 읽고 서로 감상 나누기.',5,_binary '\0',2,0,'FOLLOW','심야 북토크','0 0 22 * * SAT','2025-08-17 09:19:03.647969',1,7,2),(8,'REVIEW','2025-08-17 09:19:47.789745','자유 주제로 쓴 글을 공유하고 문장력을 다듬는 모임.',3,_binary '\0',4,0,'FOLLOW','에세이 피드백 클럽','0 30 14 * * TUE','2025-08-17 09:19:47.789750',1,8,2),(9,'STUDY','2025-08-17 09:20:33.956158','운영체제, 네트워크, 자료구조를 함께 공부하는 모임.',4,_binary '\0',0,0,'FOLLOW','CS 기본기 다지기','0 30 18 * * WED','2025-08-17 09:20:33.956163',1,9,3),(10,'STUDY','2025-08-17 09:21:04.046375','하루 한 문제 풀고 풀이를 공유하는 학습 모임.',6,_binary '\0',1,0,'FOLLOW','알고리즘 문제 풀이방','0 0 20 * * THU','2025-08-17 09:21:04.046380',1,10,3),(11,'REVIEW','2025-08-17 09:21:37.591703','대학원·논문 준비생이 모여 초안을 첨삭해주는 모임.',5,_binary '\0',5,0,'FOLLOW','연구계획서 점검 모임','0 30 16 * * WED','2025-08-17 09:21:37.591708',1,11,2),(34,'READING','2025-08-17 22:34:56.474058','오래된 명작을 함께 읽으며 현대적 해석을 덧붙이는 모임.',4,_binary '\0',1,0,'FOLLOW','고전 다시 읽기','0 30 16 * * THU','2025-08-17 22:34:56.474061',2,34,1),(35,'READING','2025-08-17 22:51:53.105822','짧은 에세이를 함께 읽고 각자 경험을 공유하는 모임.',4,_binary '\0',2,0,'FOLLOW','에세이 나눔회','0 0 22 * * THU','2025-08-17 22:51:53.105825',2,35,1),(36,'READING','2025-08-17 22:52:20.461260','같은 챕터를 읽고, 책보다 대화에 집중하는 독서 모임.',5,_binary '\0',2,0,'FOLLOW','책 대신 대화','0 30 16 * * FRI','2025-08-17 22:52:20.461263',2,36,1),(37,'READING','2025-08-17 22:53:19.183413','SF, 추리, 판타지 등 장르 소설을 같이 탐험하는 모임.',5,_binary '\0',1,0,'FOLLOW','장르 탐험대','0 30 17 * * SAT','2025-08-17 22:53:19.183418',2,37,1),(38,'READING','2025-08-17 22:53:39.294065','자기계발서나 심리학 책을 읽고 삶에 적용해보는 모임.',6,_binary '\0',1,0,'FOLLOW','마음챙김 독서','0 0 10 * * TUE','2025-08-17 22:53:39.294068',2,38,1),(39,'STUDY','2025-08-17 22:55:41.427489','IT, 회계, 공무원 등 시험 준비를 같이하는 모임.',5,_binary '\0',1,0,'FOLLOW','자격증 도전 모임','0 0 22 * * THU','2025-08-17 22:55:41.427492',2,39,3),(40,'STUDY','2025-08-17 22:56:04.467924','영어·일본어·스페인어 등 서로 학습 내용을 교환하는 모임.',4,_binary '\0',3,0,'FOLLOW','언어 교환 스터디','0 0 11 * * SUN','2025-08-17 22:56:04.467927',2,40,3),(41,'REVIEW','2025-08-17 22:58:08.151039','블로그 초안을 공유하고 가독성을 높이는 피드백 모임.',5,_binary '\0',1,0,'FOLLOW','블로그 글쓰기 첨삭방','0 0 9 * * MON','2025-08-17 22:58:08.151042',2,41,3),(42,'READING','2025-08-17 22:58:13.383301','절대 충돌해선 안돼',5,_binary '\0',0,0,'FOLLOW','깃 아마겟돈 피하기','0 0 9 * * MON','2025-08-17 22:58:13.383306',3,42,4),(43,'REVIEW','2025-08-17 22:58:36.158473','경력기술서·포트폴리오를 서로 첨삭해주는 모임.',2,_binary '\0',2,0,'FOLLOW','이력서 완성 모임','0 30 10 * * FRI','2025-08-17 22:58:36.158476',2,43,3),(44,'STUDY','2025-08-17 23:04:31.384979','논문, 튜토리얼을 함께 읽고 토론하는 모임',5,_binary '\0',0,0,'FOLLOW','AI/데이터 스터디','0 0 23 * * FRI','2025-08-17 23:04:31.384981',2,44,3),(45,'STUDY','2025-08-17 23:04:55.404175','취업 준비를 위한 학습',5,_binary '\0',1,0,'FOLLOW','취업준비 스터디','0 0 17 * * MON','2025-08-17 23:04:55.404178',2,45,3),(46,'REVIEW','2025-08-17 23:05:41.436058','독후감을 작성하는 다듬는 모임',6,_binary '\0',2,0,'FOLLOW','책 리뷰 첨삭 모임','0 0 9 * * THU','2025-08-17 23:05:41.436060',2,46,3),(47,'REVIEW','2025-08-17 23:06:14.713794','학술 초록을 피드백하는 모임',6,_binary '\0',1,0,'FOLLOW','논문 초록 첨삭 모임','0 0 9 * * MON','2025-08-17 23:06:14.713797',2,47,3),(56,'READING','2025-08-18 07:39:59.842111','라푼젤 읽고 토론해요',6,_binary '\0',1,0,'FOLLOW','라푼젤 읽기 모임','0 30 17 * * FRI','2025-08-18 07:39:59.842112',1,56,5),(57,'STUDY','2025-08-18 07:44:16.990497','SSAFY 퀴즈 모임',5,_binary '\0',1,0,'FOLLOW','SSAFY 퀴즈','0 0 11 * * SUN','2025-08-18 07:44:16.990499',1,57,1),(60,'READING','2025-08-18 10:10:55.569744','모임해요',5,_binary '\0',3,0,'FOLLOW','독서 모임','0 30 10 * * FRI','2025-08-18 10:10:55.569753',1,60,5);
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_member`
--

DROP TABLE IF EXISTS `group_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_following_host` bit(1) NOT NULL,
  `is_host` bit(1) NOT NULL,
  `joined_at` datetime(6) DEFAULT NULL,
  `progress_percent` float NOT NULL,
  `group_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `max_read_page` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK72t0d8wy6qkbgxj89o9prokdo` (`group_id`,`user_id`),
  KEY `FKfanwu738tcegh6u9uf7jrnn27` (`user_id`),
  CONSTRAINT `FK1jbvj2a8rlb8o9g2djtgpmgcn` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE,
  CONSTRAINT `FKfanwu738tcegh6u9uf7jrnn27` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_member`
--

LOCK TABLES `group_member` WRITE;
/*!40000 ALTER TABLE `group_member` DISABLE KEYS */;
INSERT INTO `group_member` VALUES (3,_binary '\0',_binary '','2025-08-17 09:14:42.653985',0,3,1,0),(4,_binary '\0',_binary '','2025-08-17 09:15:07.076268',0,4,1,0),(5,_binary '\0',_binary '','2025-08-17 09:16:17.983014',100,5,1,2),(6,_binary '\0',_binary '','2025-08-17 09:16:50.758891',0,6,1,0),(7,_binary '\0',_binary '','2025-08-17 09:19:03.657819',0,7,1,0),(8,_binary '\0',_binary '','2025-08-17 09:19:47.798079',0,8,1,0),(9,_binary '\0',_binary '','2025-08-17 09:20:33.967053',0,9,1,0),(10,_binary '\0',_binary '','2025-08-17 09:21:04.058083',0,10,1,0),(11,_binary '\0',_binary '','2025-08-17 09:21:37.598933',0,11,1,0),(58,_binary '\0',_binary '','2025-08-17 22:34:56.478652',0,34,2,0),(59,_binary '\0',_binary '','2025-08-17 22:51:53.110843',0,35,2,0),(60,_binary '\0',_binary '','2025-08-17 22:52:20.466500',0,36,2,0),(61,_binary '\0',_binary '','2025-08-17 22:53:19.187784',0,37,2,0),(62,_binary '\0',_binary '','2025-08-17 22:53:39.299073',0,38,2,0),(63,_binary '\0',_binary '','2025-08-17 22:55:41.432907',0,39,2,0),(64,_binary '\0',_binary '','2025-08-17 22:56:04.482639',0,40,2,0),(65,_binary '\0',_binary '','2025-08-17 22:58:08.158904',0,41,2,0),(66,_binary '\0',_binary '','2025-08-17 22:58:13.389837',67,42,3,2),(67,_binary '\0',_binary '','2025-08-17 22:58:36.163531',0,43,2,0),(68,_binary '\0',_binary '','2025-08-17 23:04:31.390695',0,44,2,0),(69,_binary '\0',_binary '','2025-08-17 23:04:55.409648',0,45,2,0),(70,_binary '\0',_binary '','2025-08-17 23:05:41.442051',0,46,2,0),(71,_binary '\0',_binary '','2025-08-17 23:06:14.719516',0,47,2,0),(73,_binary '\0',_binary '\0','2025-08-17 23:14:19.997849',0,38,4,0),(74,_binary '\0',_binary '\0','2025-08-17 23:14:25.582009',0,39,4,0),(75,_binary '\0',_binary '\0','2025-08-17 23:14:34.302433',0,3,4,0),(76,_binary '\0',_binary '\0','2025-08-17 23:14:38.787482',0,4,4,0),(77,_binary '\0',_binary '\0','2025-08-17 23:14:42.406402',0,6,4,0),(78,_binary '\0',_binary '\0','2025-08-17 23:15:15.136268',0,7,4,0),(79,_binary '\0',_binary '\0','2025-08-17 23:15:59.932628',0,9,4,0),(80,_binary '\0',_binary '\0','2025-08-17 23:16:57.341218',0,10,4,0),(94,_binary '\0',_binary '','2025-08-18 07:39:59.846831',75,56,1,4),(95,_binary '\0',_binary '\0','2025-08-18 07:40:09.902162',100,56,4,4),(96,_binary '\0',_binary '','2025-08-18 07:44:16.994468',100,57,1,0),(97,_binary '\0',_binary '\0','2025-08-18 07:44:31.456278',100,57,4,0),(100,_binary '\0',_binary '','2025-08-18 10:10:55.622450',0,60,1,0);
/*!40000 ALTER TABLE `group_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_member_rating`
--

DROP TABLE IF EXISTS `group_member_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_member_rating` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `score` float NOT NULL,
  `from_member_id` bigint NOT NULL,
  `group_id` bigint NOT NULL,
  `to_member_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKm4ip2kx3nigy1sf8525m845uy` (`group_id`,`from_member_id`,`to_member_id`),
  UNIQUE KEY `uq_gmr` (`group_id`,`from_member_id`,`to_member_id`),
  KEY `FKh00tst4ah3tomqfmrbu085afg` (`from_member_id`),
  KEY `FK5dwkynfge6dvadwel882ok333` (`to_member_id`),
  CONSTRAINT `FK5dwkynfge6dvadwel882ok333` FOREIGN KEY (`to_member_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKh00tst4ah3tomqfmrbu085afg` FOREIGN KEY (`from_member_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKhxhc5u0ax7w97cpvg7g7t9ar7` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_member_rating`
--

LOCK TABLES `group_member_rating` WRITE;
/*!40000 ALTER TABLE `group_member_rating` DISABLE KEYS */;
INSERT INTO `group_member_rating` VALUES (1,4.5,1,5,2);
/*!40000 ALTER TABLE `group_member_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `highlight`
--

DROP TABLE IF EXISTS `highlight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `highlight` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `color` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `endx` double NOT NULL,
  `endy` double NOT NULL,
  `group_id` bigint DEFAULT NULL,
  `page` int NOT NULL,
  `snippet` varchar(255) DEFAULT NULL,
  `startx` double NOT NULL,
  `starty` double NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `pdf_file_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK89lbqj2n3p5yjsb6rdebkj92r` (`pdf_file_id`),
  KEY `FKk1gbaokv4031svrjck5970j2d` (`group_id`),
  CONSTRAINT `FK89lbqj2n3p5yjsb6rdebkj92r` FOREIGN KEY (`pdf_file_id`) REFERENCES `pdf_file` (`pdf_id`),
  CONSTRAINT `FKk1gbaokv4031svrjck5970j2d` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `highlight`
--

LOCK TABLES `highlight` WRITE;
/*!40000 ALTER TABLE `highlight` DISABLE KEYS */;
INSERT INTO `highlight` VALUES (67,'#FFA500','2025-08-18 08:33:55.880577',105.52591705322266,693.190007686615,56,1,'일찍이  ',72.02400207519531,693.190007686615,1,NULL),(68,'#0000FF','2025-08-18 08:34:01.699575',330.4559326171875,541.1200003623962,56,1,'여자마법사  ',276.8900146484375,541.1200003623962,4,NULL),(69,'#FF0000','2025-08-18 08:34:04.977928',125.4459228515625,495.7599844932556,56,1,'키백과에는  ',72.02400207519531,495.7599844932556,1,NULL),(70,'#00FFFF','2025-08-18 08:34:06.322267',232.63595581054688,477.1600089073181,56,1,'해석했습니다.  ',166.94000244140625,477.1600089073181,4,NULL),(71,'#00FF00','2025-08-18 08:34:10.949782',291.1959228515625,423.7599844932556,56,1,'방법은  ',257.69000244140625,423.7599844932556,4,NULL),(72,'#00FF00','2025-08-18 08:34:17.065727',218.47592163085938,639.669988155365,56,1,'훌륭한  ',185.08999633789062,639.669988155365,1,NULL),(73,'#FFA500','2025-08-18 08:34:27.514699',367.7759094238281,594.5499930381775,56,1,'없었어요.  ',321.9100036621094,594.5499930381775,4,NULL),(74,'#0000FF','2025-08-18 10:13:20.739421',210.4359130859375,567.8800101280212,56,3,'시작할  ',176.89999389648438,567.8800101280212,4,NULL),(75,'#FF0000','2025-08-18 10:13:24.060518',168.64596557617188,541.1200003623962,56,3,'라푼첼아,  ',122.9000015258789,541.1200003623962,1,NULL),(76,'#00FFFF','2025-08-18 10:13:25.220291',290.4759216308594,514.4799857139587,56,3,'부여잡고  ',246.88999938964844,514.4799857139587,4,NULL),(77,'#0000FF','2025-08-18 10:13:30.338060',200.47592163085938,746.4699759483337,56,3,'숲으로  ',166.94000244140625,746.4699759483337,1,NULL),(78,'#FFFF00','2025-08-18 10:13:50.390182',150.5259246826172,639.7899832725525,56,3,'자신의  ',116.9000015258789,639.7899832725525,4,NULL),(79,'#800080','2025-08-18 10:13:59.630469',270.555908203125,487.84000158309937,56,3,'들어오는  ',226.97000122070312,487.84000158309937,1,NULL);
/*!40000 ALTER TABLE `highlight` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ocr_result`
--

DROP TABLE IF EXISTS `ocr_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ocr_result` (
  `ocr_id` bigint NOT NULL AUTO_INCREMENT,
  `line_number` int DEFAULT NULL,
  `page_number` int NOT NULL,
  `rect_h` float DEFAULT NULL,
  `rect_w` float DEFAULT NULL,
  `rect_x` float DEFAULT NULL,
  `rect_y` float DEFAULT NULL,
  `text` text,
  `word_index` int DEFAULT NULL,
  `pdf_id` bigint NOT NULL,
  PRIMARY KEY (`ocr_id`),
  KEY `FKab4y4pfrp8wjc0j2h2he2oqu5` (`pdf_id`),
  CONSTRAINT `FKab4y4pfrp8wjc0j2h2he2oqu5` FOREIGN KEY (`pdf_id`) REFERENCES `pdf_file` (`pdf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ocr_result`
--

LOCK TABLES `ocr_result` WRITE;
/*!40000 ALTER TABLE `ocr_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `ocr_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdf_file`
--

DROP TABLE IF EXISTS `pdf_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pdf_file` (
  `pdf_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `page_cnt` int NOT NULL,
  `image_based` tinyint(1) NOT NULL DEFAULT '0',
  `has_ocr` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`pdf_id`),
  KEY `FKhw0yljbrm7m60cfxrc8d0yku1` (`user_id`),
  KEY `idx_pdf_file_has_ocr` (`has_ocr`),
  CONSTRAINT `FKhw0yljbrm7m60cfxrc8d0yku1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdf_file`
--

LOCK TABLES `pdf_file` WRITE;
/*!40000 ALTER TABLE `pdf_file` DISABLE KEYS */;
INSERT INTO `pdf_file` VALUES (3,'2025-08-17 09:14:42.626209','오늘의운세.pdf','/home/ubuntu/pdf-uploads/5945cd25-d326-4f1a-a18b-0b18ddb6ea00_오늘의운세.pdf',2,0,0,1),(4,'2025-08-17 09:15:07.050213','오늘의운세.pdf','/home/ubuntu/pdf-uploads/fe754f9e-e974-463a-955f-4376902ee358_오늘의운세.pdf',2,0,0,1),(5,'2025-08-17 09:16:17.948919','Git Flow.pdf','/home/ubuntu/pdf-uploads/10952dee-2349-463c-90a2-2fc22556f698_Git Flow.pdf',3,0,0,1),(6,'2025-08-17 09:16:50.730885','오늘의운세.pdf','/home/ubuntu/pdf-uploads/eed60a06-1334-4a05-a85e-20a7391faf23_오늘의운세.pdf',2,0,0,1),(7,'2025-08-17 09:19:03.614963','오늘의운세.pdf','/home/ubuntu/pdf-uploads/5feea379-5a6e-4925-afd8-8aaefbc8f3cc_오늘의운세.pdf',2,0,0,1),(8,'2025-08-17 09:19:47.774782','오늘의운세.pdf','/home/ubuntu/pdf-uploads/729e2a1d-99fe-4cac-88fb-2bc96d6d9f40_오늘의운세.pdf',2,0,0,1),(9,'2025-08-17 09:20:33.934989','Git Flow.pdf','/home/ubuntu/pdf-uploads/817b8bfe-a758-4628-809e-601dc0722e8d_Git Flow.pdf',3,0,0,1),(10,'2025-08-17 09:21:04.024988','Git Flow.pdf','/home/ubuntu/pdf-uploads/03f894d8-b22a-420c-9309-bfde37a7f173_Git Flow.pdf',3,0,0,1),(11,'2025-08-17 09:21:37.578203','오늘의운세.pdf','/home/ubuntu/pdf-uploads/6e2ba02d-8267-4c80-b6c8-1ccdc9700030_오늘의운세.pdf',2,0,0,1),(13,'2025-08-17 09:42:49.648903','Git Flow.pdf','/home/ubuntu/pdf-uploads/6abe8442-e79c-42e0-91ae-c845eaa7ec08_Git Flow.pdf',3,0,0,1),(18,'2025-08-17 10:18:53.101398','Git Flow.pdf','/home/ubuntu/pdf-uploads/4abe88e0-9065-40e6-a1bb-6198da6f321f_Git Flow.pdf',3,0,0,1),(23,'2025-08-17 12:12:39.799372','어린왕자.pdf','/home/ubuntu/pdf-uploads/c7965688-82e8-4849-b793-15bfd455fe87_어린왕자.pdf',1,0,0,1),(24,'2025-08-17 17:09:21.786702','Git Flow.pdf','/home/ubuntu/pdf-uploads/631849f7-28cf-42d2-9926-a27d673289f8_Git Flow.pdf',3,0,0,1),(26,'2025-08-17 18:02:20.827803','Git Flow.pdf','/home/ubuntu/pdf-uploads/acf04423-2c43-4c21-afe3-493251da1f53_Git Flow.pdf',4,0,0,3),(27,'2025-08-17 20:34:43.782177','SSAFY 북글북글 팀 최종발표.pdf','/home/ubuntu/pdf-uploads/ce11b1db-6177-456b-83ee-74140ef4f6b7_SSAFY 북글북글 팀 최종발표.pdf',1,0,0,3),(28,'2025-08-17 20:43:21.460639','어린왕자.pdf','/home/ubuntu/pdf-uploads/2f212c35-318a-4dc6-a42b-9d786459f4f0_어린왕자.pdf',1,0,0,4),(30,'2025-08-17 20:48:17.847088','Git Flow.pdf','/home/ubuntu/pdf-uploads/657ecca6-ee7b-49e8-9d78-f03b902384d7_Git Flow.pdf',3,0,0,4),(34,'2025-08-17 22:34:56.459111','어린왕자.pdf','/home/ubuntu/pdf-uploads/21862786-a871-43fe-abde-7034b2bcb9bc_어린왕자.pdf',1,0,0,2),(35,'2025-08-17 22:51:53.088725','어린왕자.pdf','/home/ubuntu/pdf-uploads/e92685c6-b499-454e-81d6-45116949a4ca_어린왕자.pdf',1,0,0,2),(36,'2025-08-17 22:52:20.448214','어린왕자.pdf','/home/ubuntu/pdf-uploads/850e83f2-e2ed-41c8-9db8-2184b98b9e18_어린왕자.pdf',1,0,0,2),(37,'2025-08-17 22:53:19.170524','어린왕자.pdf','/home/ubuntu/pdf-uploads/51bbc6c5-37d4-4951-81c4-0be6eeaae0e1_어린왕자.pdf',1,0,0,2),(38,'2025-08-17 22:53:39.280516','어린왕자.pdf','/home/ubuntu/pdf-uploads/b48077a3-f968-4eb8-91f6-d65a83e4ccb2_어린왕자.pdf',1,0,0,2),(39,'2025-08-17 22:55:41.406314','Git Flow.pdf','/home/ubuntu/pdf-uploads/ee99175a-2484-4ab0-977f-0c86010a88ed_Git Flow.pdf',3,0,0,2),(40,'2025-08-17 22:56:04.446110','Git Flow.pdf','/home/ubuntu/pdf-uploads/12b97481-920b-466f-a7bd-e6d14308a0f9_Git Flow.pdf',3,0,0,2),(41,'2025-08-17 22:58:08.130680','Git Flow.pdf','/home/ubuntu/pdf-uploads/9357998e-bea4-4954-a123-722814b7a4c2_Git Flow.pdf',3,0,0,2),(42,'2025-08-17 22:58:13.360817','Git Flow.pdf','/home/ubuntu/pdf-uploads/8e92024e-3850-4a2b-b2c7-268b684b3650_Git Flow.pdf',4,0,0,3),(43,'2025-08-17 22:58:36.139303','Git Flow.pdf','/home/ubuntu/pdf-uploads/cbba2630-7f58-435a-834f-8ba4da839a25_Git Flow.pdf',3,0,0,2),(44,'2025-08-17 23:04:31.365768','Git Flow.pdf','/home/ubuntu/pdf-uploads/51eeecc4-c237-4423-b742-8f853dfed72b_Git Flow.pdf',3,0,0,2),(45,'2025-08-17 23:04:55.385031','Git Flow.pdf','/home/ubuntu/pdf-uploads/3a816c19-2deb-486f-9eb2-003bff2dc653_Git Flow.pdf',3,0,0,2),(46,'2025-08-17 23:05:41.409609','Git Flow.pdf','/home/ubuntu/pdf-uploads/ee2b806f-414d-422b-9d86-b57d7253269e_Git Flow.pdf',3,0,0,2),(47,'2025-08-17 23:06:14.694612','Git Flow.pdf','/home/ubuntu/pdf-uploads/4fdc623a-7b6c-40db-a8b5-97b6850ff592_Git Flow.pdf',3,0,0,2),(49,'2025-08-17 23:55:57.884520','라푼첼.pdf','/home/ubuntu/pdf-uploads/d95b5575-6e67-4e5f-b5ff-2240ba742e7d_라푼첼.pdf',5,0,0,1),(51,'2025-08-18 00:29:22.339230','라푼첼.pdf','/home/ubuntu/pdf-uploads/8e68d118-6e67-4eb9-9d42-381d3037dba2_라푼첼.pdf',5,0,0,1),(56,'2025-08-18 07:39:59.809323','라푼첼.pdf','/home/ubuntu/pdf-uploads/4bf4d8df-af12-440b-bf4c-2bec49e7ad10_라푼첼.pdf',5,0,0,1),(57,'2025-08-18 07:44:16.986144','SSAFY 북글북글 팀 최종발표 (1).pdf','/home/ubuntu/pdf-uploads/e9e3bef1-28c9-4343-8178-c97f407ec181_SSAFY 북글북글 팀 최종발표 (1).pdf',1,0,0,1),(60,'2025-08-18 10:10:55.212842','라푼첼.pdf','/home/ubuntu/pdf-uploads/e52bf60d-3d73-4dfb-8704-1c1a5e62662f_라푼첼.pdf',5,0,0,1);
/*!40000 ALTER TABLE `pdf_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdf_reading_progress`
--

DROP TABLE IF EXISTS `pdf_reading_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pdf_reading_progress` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `updated_at` datetime(6) DEFAULT NULL,
  `group_group_id` bigint DEFAULT NULL,
  `user_user_id` bigint DEFAULT NULL,
  `group_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `max_read_page` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pdf_progress_user_group` (`user_id`,`group_id`),
  KEY `FKhs05w1n1d44tbwpeg7ke723ec` (`group_group_id`),
  KEY `FKds3tma4n48h6w9919jkcsq1jp` (`user_user_id`),
  KEY `FK6xrdw99r8uu8oktj8jk7svaag` (`group_id`),
  CONSTRAINT `FK6xrdw99r8uu8oktj8jk7svaag` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`),
  CONSTRAINT `FKds3tma4n48h6w9919jkcsq1jp` FOREIGN KEY (`user_user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKhs05w1n1d44tbwpeg7ke723ec` FOREIGN KEY (`group_group_id`) REFERENCES `group` (`group_id`),
  CONSTRAINT `FKrc2kttrjrnvrisarrpbvnr2ym` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdf_reading_progress`
--

LOCK TABLES `pdf_reading_progress` WRITE;
/*!40000 ALTER TABLE `pdf_reading_progress` DISABLE KEYS */;
INSERT INTO `pdf_reading_progress` VALUES (13,'2025-08-17 11:30:08.000000',NULL,NULL,5,2,3),(14,'2025-08-17 11:30:29.000000',NULL,NULL,5,1,3),(24,'2025-08-17 23:22:15.705591',NULL,NULL,42,3,2),(34,'2025-08-17 23:02:28.000000',NULL,NULL,56,4,5),(35,'2025-08-18 01:13:36.000000',NULL,NULL,56,1,5),(36,'2025-08-17 22:44:33.000000',NULL,NULL,57,1,1),(37,'2025-08-17 22:44:33.000000',NULL,NULL,57,4,1);
/*!40000 ALTER TABLE `pdf_reading_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdf_viewing_session`
--

DROP TABLE IF EXISTS `pdf_viewing_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pdf_viewing_session` (
  `id` bigint NOT NULL,
  `duration_seconds` bigint DEFAULT NULL,
  `enter_time` datetime(6) DEFAULT NULL,
  `exit_time` datetime(6) DEFAULT NULL,
  `group_group_id` bigint DEFAULT NULL,
  `user_user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKew07o00f2col3holpxrdy5eua` (`group_group_id`),
  KEY `FK5oh096mg3r9io15o3q3g0qx97` (`user_user_id`),
  CONSTRAINT `FK5oh096mg3r9io15o3q3g0qx97` FOREIGN KEY (`user_user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKew07o00f2col3holpxrdy5eua` FOREIGN KEY (`group_group_id`) REFERENCES `group` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdf_viewing_session`
--

LOCK TABLES `pdf_viewing_session` WRITE;
/*!40000 ALTER TABLE `pdf_viewing_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdf_viewing_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdf_viewing_session_seq`
--

DROP TABLE IF EXISTS `pdf_viewing_session_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pdf_viewing_session_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdf_viewing_session_seq`
--

LOCK TABLES `pdf_viewing_session_seq` WRITE;
/*!40000 ALTER TABLE `pdf_viewing_session_seq` DISABLE KEYS */;
/*!40000 ALTER TABLE `pdf_viewing_session_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_token`
--

DROP TABLE IF EXISTS `refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_token` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_token`
--

LOCK TABLES `refresh_token` WRITE;
/*!40000 ALTER TABLE `refresh_token` DISABLE KEYS */;
INSERT INTO `refresh_token` VALUES ('gews30025@naver.com','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJnZXdzMzAwMjVAbmF2ZXIuY29tIiwiaWF0IjoxNzU1NDc5MDgxLCJleHAiOjE3NTY2ODg2ODF9.KKUMvffN0tqF6dSYTAMdnrvpJv0iea_NkIscJNPkva8'),('gews300255@gmail.com','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJnZXdzMzAwMjU1QGdtYWlsLmNvbSIsImlhdCI6MTc1NTQ3OTA4NSwiZXhwIjoxNzU2Njg4Njg1fQ.G20sUoMOl9KkcCFxveyRW2cG_eqevcdE_PAipRjUzMk'),('gewss300255@gmail.com','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJnZXdzczMwMDI1NUBnbWFpbC5jb20iLCJpYXQiOjE3NTU0NDI3MjAsImV4cCI6MTc1NjY1MjMyMH0.x6JahB9fQKbbVJJXPKNRAtFgBxq8-yxXOB5ipsvlGrQ'),('rkddkwl059@yu.ac.kr','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJya2Rka3dsMDU5QHl1LmFjLmtyIiwiaWF0IjoxNzU1NDcwMDY5LCJleHAiOjE3NTY2Nzk2Njl9.SUhveQCJ8SIO7Dm2RQXHv4bCVALh3n5G0pzF_l7KguI');
/*!40000 ALTER TABLE `refresh_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_device`
--

DROP TABLE IF EXISTS `user_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_device` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `enabled` bit(1) NOT NULL,
  `last_seen_at` datetime(6) DEFAULT NULL,
  `token` varchar(2048) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnnbvbh186cbm7wqvp89ffsfqg` (`user_id`),
  CONSTRAINT `FKnnbvbh186cbm7wqvp89ffsfqg` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_device`
--

LOCK TABLES `user_device` WRITE;
/*!40000 ALTER TABLE `user_device` DISABLE KEYS */;
INSERT INTO `user_device` VALUES (1,_binary '','2025-08-17 23:48:13.463496','euE-j1omQBeZDmT-xybnq5:APA91bF45mLfJ22w7x3w_yx0yXFqjI4jQWpLm45F-rL_BXKfTj7XoHeJ-heKb17HXGh3RzWJjyvX_1L_0Bme4_PJhxsZItSOtYL0qfYqWlb_Ub0Y5JQfbD8',1),(2,_binary '\0','2025-08-17 11:15:43.422675','e0GuZBQrRla4aZ557SeBOB:APA91bE2qBkbWOtRXOp8nNZAQp0pUZuyh2iqmxjmdOc9gifO-ZrcGc9rJd-Kqh1lpFUDtyRbVBd43MKmwrXJUjNY2ZUBoDnUqHd2Yo_0rLYaVaihmFByLVE',2),(3,_binary '\0','2025-08-17 11:28:00.862642','cbRcEXl2QJyh_1cXhIRH-y:APA91bFYVX7a8szkfwNXWUt4sPh3ovb8ZLJSCn0mz6eRQOfj2TAlHN0e6DJStF-lJ791kkdzPGSbxvNB98nv33e0f_0XWOW62sp3IUQcc5jsYQg7nfAQzLk',2),(4,_binary '\0','2025-08-17 20:29:17.669501','euE-j1omQBeZDmT-xybnq5:APA91bF45mLfJ22w7x3w_yx0yXFqjI4jQWpLm45F-rL_BXKfTj7XoHeJ-heKb17HXGh3RzWJjyvX_1L_0Bme4_PJhxsZItSOtYL0qfYqWlb_Ub0Y5JQfbD8',2),(5,_binary '\0','2025-08-17 11:33:21.245420','eKfzFrHPTPSA-2nz4U1NpE:APA91bHgrkFMcMeobRkPJCz342MCqM5_VuVDgJwL5d_nDsjgoy6v4OAgHnIhJ_ryhqKLRZ4ykjNqWVwOUoPPxNkuYP5WIxWeil1u1FurhUsC5EXtWmCjO6Y',1),(6,_binary '\0','2025-08-17 11:56:42.659589','cKF6WXqiSeuvcE2KDcy9aG:APA91bGM2COsZozieVWmZw-3TvwgjgVgesmezKsdg3g6cBem2fgo9Rha9ZVAB8ELnITTYZ2D432ykNV9u932HxIUPLbnwkZ96-kO49I9qHVEYXtraHlIwWE',2),(7,_binary '\0','2025-08-17 15:24:59.494669','dBm3CHbFR4aj04yjA-C-yT:APA91bG4U4x-UmPlBMNCZrkoy-bf4bptzSHTE5WlxdrP2AJbiQMJYHuuWS2z5KQrq6Hc5KRGN_l8iDqtbiC6ozqftMjmmc0HUb2VvyEShWpLR369U_V3vRY',2),(8,_binary '','2025-08-17 17:14:30.206508','cA8pOGupR_2VZeGu8HLPLg:APA91bG6UT1FhPUmsbse6tG1TtKsQYxwedZL96-n2a4ipWnDgRT10KPmFx1UdRoYAxD9RLQMWGWDJIJsZCC9VCuIqruB3uUZtW43ADYB_vYrgkAeGxXmNWo',2),(9,_binary '','2025-08-18 02:52:26.492029','eYEWth-BTnKZfm799D2Axa:APA91bEVqdxGxUlvQH3Hg_VH_W9czSI1JP4iHtLmdj6WOj_Qr9DNk4ECsmzOx60w_AKTqd6L7zLkmgBgGfApK9LAYUit91FKlgD7yI8Jk5ch30rdjqx3BQ8',3),(10,_binary '\0','2025-08-17 19:32:04.707676','ee_foIYGT7Kt3rSani28o-:APA91bH5pYqipTna7mLBWMuiPNhxwh4lnwHfFB6mb8BJMjxMuoSyOnsgxArqyEtMNY8QLXQJT9y50c2NvZNYPXQTYmsvequEueLUykuanJ_lOUpuxZ5fuJY',1),(11,_binary '\0','2025-08-17 22:34:23.956079','ee_foIYGT7Kt3rSani28o-:APA91bH5pYqipTna7mLBWMuiPNhxwh4lnwHfFB6mb8BJMjxMuoSyOnsgxArqyEtMNY8QLXQJT9y50c2NvZNYPXQTYmsvequEueLUykuanJ_lOUpuxZ5fuJY',2),(12,_binary '','2025-08-17 23:41:41.383715','eFmLXvadQQe_CTt-wOrWY_:APA91bEhH4gG964ARGu6jvTIhHo76GPD3M9_sgbGCSFalaDzLIiZKt1SRsmgYsl7MT0rfU4UoSz8Ixk73HTyZa8m-AcbSzlLBzW7I7SH2y3PElkLxX-79hg',4),(13,_binary '','2025-08-18 10:04:45.303714','fxCNQ1T3RJqP65NiED1hmG:APA91bFZpsH-TfDfV4UA7Ii1xNn4HBNqt7Ixn67EvVastwGXdSIDEXo0rOddT8lgPP_sS1Q_eFEKgQZ6Uaxy2XW6St9eEN92897YoUUvLhULhduSKWguhZY',4),(14,_binary '\0','2025-08-17 23:58:40.046465','cH4_N92uTAWiIxVhAAMaph:APA91bFXAv5IIP8DV507F-cCMcwDOcEn113vdyZ_WswRb7PGMl_mPMeXo_iMZOWSbEF5S-sfGWH0Rjp7_HDGaHi2D2iDiZ90q5gPVyYh5KxEKPPKQbGVzDY',2),(15,_binary '','2025-08-18 10:04:41.974024','cH4_N92uTAWiIxVhAAMaph:APA91bFXAv5IIP8DV507F-cCMcwDOcEn113vdyZ_WswRb7PGMl_mPMeXo_iMZOWSbEF5S-sfGWH0Rjp7_HDGaHi2D2iDiZ90q5gPVyYh5KxEKPPKQbGVzDY',1);
/*!40000 ALTER TABLE `user_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_rating`
--

DROP TABLE IF EXISTS `user_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_rating` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `g_id` bigint DEFAULT NULL,
  `rater_id` bigint DEFAULT NULL,
  `ratee_id` bigint DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_user_rating_group` (`g_id`),
  KEY `fk_user_rating_rater` (`rater_id`),
  KEY `fk_user_rating_ratee` (`ratee_id`),
  CONSTRAINT `fk_user_rating_group` FOREIGN KEY (`g_id`) REFERENCES `group` (`group_id`),
  CONSTRAINT `fk_user_rating_ratee` FOREIGN KEY (`ratee_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fk_user_rating_rater` FOREIGN KEY (`rater_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_rating`
--

LOCK TABLES `user_rating` WRITE;
/*!40000 ALTER TABLE `user_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `avg_rating` float DEFAULT NULL,
  `user_email` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `rating_cnt` int DEFAULT NULL,
  `profile_color` varchar(9) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  `deactivated_at` datetime(6) DEFAULT NULL,
  `total_active_seconds` bigint NOT NULL DEFAULT '0',
  `total_active_hours` int GENERATED ALWAYS AS (floor((`total_active_seconds` / 3600))) STORED,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK33uo7vet9c79ydfuwg1w848f` (`user_email`),
  UNIQUE KEY `UK2ty1xmrrgtn89xt7kyxx6ta7h` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`, `avg_rating`, `user_email`, `nickname`, `password`, `profile_image_url`, `provider`, `rating_cnt`, `profile_color`, `is_active`, `deactivated_at`, `total_active_seconds`) VALUES (1,4.6,'gews30025@naver.com','최싸피','$2a$10$ZBlzop/l8tqmmRiy.SynSOY5d5OOoHHzRC2K2Wey1SuqArBoENEeS','whitebear',NULL,1,'#9C27B0',_binary '',NULL,6000),(2,4.7,'gewss300255@gmail.com','홍은솔','$2a$10$YxAJyShloVgK9d6Pkc5Mledi01LhfjLXlfnaaHIIG2hKbJMuvePa.','rabbit',NULL,1,'#7DDA58',_binary '',NULL,0),(3,4.3,'rkddkwl059@yu.ac.kr','송진우1',NULL,NULL,'google',0,NULL,_binary '',NULL,0),(4,4.3,'gews300255@gmail.com','송진우',NULL,'whitebear','google',0,'#5B7FFF',NULL,NULL,0),(5,5,'test@example.com','테스트유저','$2a$10$hZwUBSfJ4xPCTplWuiT6e.QMtWM8xakRJ7Q6om2RuYoHwAjssTSQa',NULL,NULL,NULL,NULL,NULL,NULL,0),(6,5,'ssafy@yssafy.com','김싸피','$2a$10$DGexGeTQseuolmOlnn/kGur.QDi8h6vOwmu.4lOHwIsDXU3ZZsuom',NULL,NULL,1,NULL,_binary '',NULL,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_code`
--

DROP TABLE IF EXISTS `verification_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_code` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_code`
--

LOCK TABLES `verification_code` WRITE;
/*!40000 ALTER TABLE `verification_code` DISABLE KEYS */;
INSERT INTO `verification_code` VALUES (1,'810164','2025-08-17 09:05:54.571885','gews30025@naver.com'),(2,'500578','2025-08-17 09:58:29.367682','gewss300255@gmail.com'),(3,'996058','2025-08-18 01:57:39.763258','ssafy@ssafy.com');
/*!40000 ALTER TABLE `verification_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'bookglebookgle'
--

--
-- Dumping routines for database 'bookglebookgle'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  2:25:46
